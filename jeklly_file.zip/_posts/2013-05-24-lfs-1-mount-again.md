---
layout: post
title: 恢复base linux链
tags:
    - lfs
    - toolschain
---

确认export 
>
    mount -v --bind /dev $LFS/dev


bind 

root

export LFS=/mnt/lfs

